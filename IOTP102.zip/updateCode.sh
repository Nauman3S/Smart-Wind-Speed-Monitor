#!/bin/bash

scp -r Firmware pi@raspberrypi1.local:/home/pi/
