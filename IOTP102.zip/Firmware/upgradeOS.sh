#!/bin/sh
sudo apt update && sudo upgrade -y