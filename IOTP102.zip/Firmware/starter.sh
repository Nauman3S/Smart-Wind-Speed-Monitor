killall -9 python3
sudo killall -9 python3
python3 main.py